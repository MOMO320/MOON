#pragma once

//==================================================
//commonMacroFunction(�ʿ��� �κ��� ���� �����ÿ�)
//==================================================

//����Ʈ
inline POINT PointMake(int x, int y)
{
	POINT pt = { x ,y };
	return pt;
}
//���׸��� �Լ�
inline void LineMake(HDC hdc, int x1, int y1, int x2, int y2)
{
	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
}
inline void LineMake(HDC hdc, POINT p1, POINT p2)
{
	MoveToEx(hdc, p1.x, p1.y, NULL);
	LineTo(hdc, p2.x, p2.y);
}
//RECT�����(�»�� ����)
inline RECT RectMake(int x, int y, int width, int height)
{
	RECT rc = { x,y, x + width, y + height };
	return rc;
}
//RECT�����(�߽������� ����)
inline RECT RectMakeCenter(int x, int y, int width, int height)
{
	RECT rc = { x - width / 2, y - height / 2, x + width / 2, y + height / 2 };

	return rc;
}
//�簢�� �׸���
inline void RectangleMake(HDC hdc, int x, int y, int width, int height)
{
	Rectangle(hdc, x, y, x + width, y + height);
}
inline void RectangleMake(HDC hdc, RECT rect)
{
	Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);
}
//�簢�� �׸���(�߽���)
inline void RectangleMakeCenter(HDC hdc, int x, int y, int width, int height)
{
	Rectangle(hdc, x - (width / 2), y - (height / 2), x + (width / 2), y + (height / 2));
}
//���׸���
inline void EllipseMake(HDC hdc, int x, int y, int width, int height)
{
	Ellipse(hdc, x, y, x + width, y + height);
}
//���׸���(�߽���)
inline void EllipseMakeCenter(HDC hdc, int x, int y, int width, int height)
{
	Ellipse(hdc, x - (width / 2), y - (height / 2), x + (width / 2), y + (height / 2));

}
inline void BeginSolidColor(HDC hdc, HBRUSH* brush, COLORREF color)
{
	*brush = CreateSolidBrush(color);
	*brush = (HBRUSH)SelectObject(hdc, *brush);

}

inline void colorRectangle(HDC hdc, int x, int y, int width, int height, int _r, int _g, int _b)
{
	HBRUSH brush;
	RECT rc = { x,y, x + width, y + height };
	brush = CreateSolidBrush(RGB(_r, _g, _b));
	FillRect(hdc, &rc, brush);

	DeleteObject(brush);
}

//���� �簢�� �׸���
inline void AlphaRectangle(HDC hdc, int left, int top, int right, int bottom)
{
	HBRUSH myBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
	HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, myBrush);

	Rectangle(hdc, left, top, right, bottom);

	SelectObject(hdc, oldBrush);
	DeleteObject(myBrush);
}

inline void printText(HDC _hdc, const char* _str, const char * _font, int _destX, int _destY,
	int _fontSize, COLORREF _fontColor, bool _isBgTransParent, COLORREF _bgColor)
{
	HFONT curFont, oldFont;
	COLORREF oldBkColor, oldFontColor;
	int len = strlen(_str);
	if (_fontColor != RGB(244, 244, 233))
		oldFontColor = SetTextColor(_hdc, _fontColor);
	if (_bgColor != RGB(255, 255, 255))
		oldBkColor = SetBkColor(_hdc, _bgColor);
	if (_isBgTransParent)
		SetBkMode(_hdc, TRANSPARENT);
	else
		SetBkMode(_hdc, OPAQUE);

	curFont = CreateFont(_fontSize, 0, 0, 0, FW_DONTCARE,
		FALSE, FALSE, FALSE, DEFAULT_CHARSET,
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		FF_DONTCARE, _font
	);

	oldFont = (HFONT)SelectObject(_hdc, curFont);
	TextOut(_hdc, _destX, _destY, _str, len);
	SelectObject(_hdc, oldFont);

	DeleteObject(curFont);
	if (_fontColor != RGB(0, 0, 0))
		SetTextColor(_hdc, oldFontColor);
	if (_bgColor != RGB(255, 255, 255))
		SetBkColor(_hdc, oldBkColor);
	if (_isBgTransParent)
		SetBkMode(_hdc, OPAQUE);
}
