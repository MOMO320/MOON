#include "stdafx.h"
#include "enemies.h"

enemies::enemies()
{
}

enemies::~enemies()
{
}

HRESULT enemies::init()
{
	//m_enemy1.name = "�ڽ�";
	//m_enemy1._rc = RectMakeCenter(WINSIZEX - 180, WINSIZEY / 2, 80, 80);
	//SetRect(&m_enemy1._fightColli,
	//	300, 100, (WINSIZEX / 2) + 450, (WINSIZEY / 2) + 260);
	//m_enemy1.speed = 100;
	////  player �� enemy �浹ó�� �� ����
	return S_OK;
}

void enemies::release()
{
}

void enemies::update(RECT rc)
{
}

void enemies::render(int x, int y)
{
	//AlphaRectangle(getMemDC(), m_enemy1._fightColli.left, m_enemy1._fightColli.top, m_enemy1._fightColli.right , m_enemy1._fightColli.bottom);
	//colorRectangle(getMemDC(), m_enemy1._rc.left, m_enemy1._rc.top, 80, 80, 255, 69, 000);
}

