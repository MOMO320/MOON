#pragma once
#include "gameNode.h"

struct enemy
{
	RECT		_rc;
	RECT		_fightColli;

	image*		m_img;
	animation*	m_ani;

	string		name;
	int			attack;
	int			hp;
	int			speed;
};

class enemies : public gameNode
{
public:
	enemies();
	~enemies();

	virtual HRESULT init() = 0;
	virtual void release() = 0;
	virtual void update() = 0;
	virtual void render(int x, int y) = 0;
	
	virtual void enemySetRect() = 0;

	virtual void setRect(RECT _rc) = 0;
	virtual enemy getEnemyInfo() = 0;

	//virtual void setRect(RECT _rc) { m_enemy1._rc = _rc; }
	//virtual enemy getEnemyInfo() { return m_enemy1; }

	//enemy m_enemy1;

protected :
	float pastTime;
	float addDeleyTime = 0.5;

private:
	


};

