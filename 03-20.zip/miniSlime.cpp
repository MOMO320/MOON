#include "stdafx.h"
#include "miniSlime.h"

miniSlime::miniSlime()
{
}

miniSlime::~miniSlime()
{
}

HRESULT miniSlime::init()
{
	m_miniSlime.m_img = IMAGEMANAGER->findImage("miniSlime");
	m_miniSlime.m_ani = ANIMATIONMANAGER->findAnimation("miniSlime_Ani");

	m_miniSlime.name = "�̴Ͻ�����";
	m_miniSlime.attack = 3;
	m_miniSlime.hp = 15;
	m_miniSlime.speed = SLIMESPEED;

	m_miniSlime.m_ani->start();

	enemySetRect();

	pastTime = 0;

	return S_OK;
}

void miniSlime::release()
{
	IMAGEMANAGER->deleteAll();
	ANIMATIONMANAGER->deleteALL();
}

void miniSlime::update()
{
}

void miniSlime::update()
{
	if (m_miniSlime.hp < 0)
	{
		m_isDeath = true;
		m_miniSlime.m_img = IMAGEMANAGER->findImage("miniSlimeDeath");
	}
}

void miniSlime::render(int x, int y)
{
	float elapsedTime;

	elapsedTime = TIMEMANAGER->getElapsedTime();


	m_miniSlime.m_img->aniRender(getMemDC(), x, y, m_miniSlime.m_ani);
	
	if (m_isDeath)
	{
		pastTime += elapsedTime;
		
		for (int i = 0; i <= 100 ;i)
		{
		    if (addDeleyTime < pastTime)
		    {
				m_miniSlime.m_img->alphaRender(getMemDC(), i);
				i += 20;
		    }
		}
	}
}

void miniSlime::enemySetRect()
{
	SetRect(&m_miniSlime._fightColli, 300, 100,
		(WINSIZEX / 2) + 450, (WINSIZEY / 2) + 260);
	
	m_miniSlime._rc = RectMakeCenter(WINSIZEX - 300, 500, m_miniSlime.m_img->getWidth(), m_miniSlime.m_img->getHeight());
}



